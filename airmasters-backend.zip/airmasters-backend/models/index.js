module.exports = {
Client: require('./Client'),
Appointment: require('./Appointment')
};