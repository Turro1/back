const {check} = require('express-validator');

const validation = {
    create: [
        check('fullname').isLength({min: 6}),
        check('carname').isLength({min: 3}),
        check('carmodel').isLength({min: 1}),
        check('phone').isLength({min: 8}),
        check('carnumber').isLength({min: 6})
]
};

module.exports = validation;