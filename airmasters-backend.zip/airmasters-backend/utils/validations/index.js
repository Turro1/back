module.exports = {
    clientValidation: require('./client'),
    appointmentValidation: require('./appointment')
}